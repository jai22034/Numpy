import numpy as np
arr1= np.random.rand(10,20)
arr2= np.random.rand(20,25)
print(np.dot(arr1,arr2))
x=np.dot(arr1,arr2)
y=np.add(x)
print(y)