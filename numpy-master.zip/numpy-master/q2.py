import numpy as np
arr= np.random.rand(20,1)
x=np.var(arr)
y=np.std(arr)
print(x)
print(y)