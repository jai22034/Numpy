import numpy as np
arr= np.random.rand(10,1)
x=np.mean(arr)
print(x)